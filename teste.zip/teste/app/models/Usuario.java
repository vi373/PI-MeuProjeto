package models;

import play.db.jpa.Model;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.List;

@Entity
public class Usuario extends Model {

    public String nome;
    public String email;

    @Column(unique = true)
    public String login;

    /** Neste campo armazena-se o hash SHA-256 */
    public String senhaHash;

    @Enumerated(EnumType.STRING)
    public Perfil perfil;

    @ManyToOne
    public Departamento departamento;

    @Enumerated(EnumType.STRING)
    public Status status;

    @Temporal(TemporalType.DATE)
    public Date dataNascimento;

    @Transient
    public Integer idade;

    public Usuario() {
        this.status = Status.ATIVO;
        this.perfil = Perfil.ASSISTENTE;
    }

    // ---------- helpers ----------
    public void setSenha(String senhaPlain) {
        this.senhaHash = sha256(senhaPlain);
    }

    public boolean confereSenha(String senhaPlain) {
        if (senhaHash == null) return false;
        return senhaHash.equals(sha256(senhaPlain));
    }

    private String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes());
            Formatter formatter = new Formatter();
            for (byte b : digest) {
                formatter.format("%02x", b);
            }
            String res = formatter.toString();
            formatter.close();
            return res;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public int getIdade() {
        if (idade == null && dataNascimento != null) {
            LocalDate localDataNascimento = dataNascimento.toInstant()
                    .atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate agora = LocalDate.now();
            Period period = Period.between(localDataNascimento, agora);
            idade = period.getYears();
        }
        return idade == null ? 0 : idade;
    }

    @Override
    public String toString() {
        return nome + " [" + login + "] - " + perfil;
    }

    // ---------- consultas uteis ----------
    public static List<Usuario> buscar(String termo) {
        if (termo == null || termo.trim().isEmpty()) {
            return Usuario.findAll();
        }
        String like = "%" + termo.toLowerCase() + "%";
        return Usuario.find("lower(nome) like ?1 or lower(login) like ?1 or lower(email) like ?1", like).fetch();
    }

    public static Usuario autenticar(String login, String senhaPlain) {
        if (login == null || senhaPlain == null) return null;
        Usuario u = Usuario.find("byLogin", login).first();
        if (u == null) return null;
        if (u.status != Status.ATIVO) return null;
        return u.confereSenha(senhaPlain) ? u : null;
    }
}
