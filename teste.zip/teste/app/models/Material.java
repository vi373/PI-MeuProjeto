package models;

import javax.persistence.*;
import java.util.Date;
import play.db.jpa.Model;

@Entity
public class Material extends Model {
    public String nome;
    public String codigo;
    public String categoria;
    public int quantidade;
    public String descricao;

    @Enumerated(EnumType.STRING)
    public Status status;

    @Temporal(TemporalType.TIMESTAMP)
    public Date dataEntrada;

    @ManyToOne
    public Estoque estoque;

    public Material() {
        this.dataEntrada = new Date();
        this.status = Status.ATIVO;
    }

    @Override
    public String toString() {
        return String.format("Material[id=%d, nome=%s, codigo=%s, quantidade=%d, status=%s]",
                id, nome, codigo, quantidade, status);
    }
}
