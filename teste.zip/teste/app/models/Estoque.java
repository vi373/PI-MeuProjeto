package models;

import javax.persistence.*;
import java.util.Date;
import play.db.jpa.Model;

@Entity
public class Estoque extends Model {
    public String nome;
    public String codigo;
    public String categoria;
    public int quantidade;
    public String descricao;

    @Enumerated(EnumType.STRING)
    public Status status;

    public boolean removido = false;

    public Estoque() { }

    public Estoque(String nome, String codigo, String categoria, int quantidade, String descricao, Status status) {
        this.nome = nome;
        this.codigo = codigo;
        this.categoria = categoria;
        this.quantidade = quantidade;
        this.descricao = descricao;
        this.status = status;
        this.removido = false;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + " - Código: " + codigo + " - Quantidade: " + quantidade;
    }
}
