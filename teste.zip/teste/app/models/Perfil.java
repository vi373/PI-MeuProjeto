package models;

public enum Perfil {
    ADMINISTRADOR, ASSISTENTE
}
