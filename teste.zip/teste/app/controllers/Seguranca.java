package controllers;

import play.mvc.Before;
import play.mvc.Controller;

public class Seguranca extends Controller {

    @Before
    static void verificarLogin() {
        String path = request.action;
        if (path.startsWith("Materiais.") && !session.contains("usuarioLogado")) {
            flash.error("Faça login para acessar o sistema.");
            Logins.form();
        }
    }
}
