package controllers;

import models.Usuario;
import play.mvc.Controller;

public class Usuarios extends Controller {

    public static void form() {
        render();
    }

    public static void salvar(Usuario usuario) {
        // validações obrigatórias
        if (usuario.nome == null || usuario.nome.trim().isEmpty()) {
            flash.error("Nome é obrigatório.");
            form();
        }
        if (usuario.email == null || usuario.email.trim().isEmpty()) {
            flash.error("E-mail é obrigatório.");
            form();
        }
        if (usuario.login == null || usuario.login.trim().isEmpty()) {
            flash.error("Login é obrigatório.");
            form();
        }
        if (params.get("usuario.senha") == null || params.get("usuario.senha").trim().isEmpty()) {
            flash.error("Senha é obrigatória.");
            form();
        }
        if (usuario.perfil == null) {
            flash.error("Selecione um perfil.");
            form();
        }

        // Senha
        usuario.setSenha(params.get("usuario.senha").trim());
        usuario.save();

        flash.success("Usuário cadastrado com sucesso! Faça login.");
        Logins.form();
    }
}
