package controllers;

import models.Material;
import models.Status;
import play.mvc.Controller;
import play.data.validation.Valid;
import java.util.List;
import java.util.ArrayList;

public class Materiais extends Controller {

    public static void form() { render(); }

    public static void listar(String termo) {
        List<Material> materiais;
        try {
            if (termo != null && !termo.trim().isEmpty()) {
                List<Material> todos = Material.findAll();
                materiais = new ArrayList<Material>();
                String termoLower = termo.toLowerCase().trim();
                for (Material m : todos) {
                    if ((m.nome != null && m.nome.toLowerCase().contains(termoLower)) ||
                        (m.codigo != null && m.codigo.toLowerCase().contains(termoLower))) {
                        materiais.add(m);
                    }
                }
            } else {
                materiais = Material.findAll();
            }
        } catch (Exception e) {
            materiais = new ArrayList<Material>();
            flash.error("Erro ao carregar materiais: " + e.getMessage());
        }
        render(materiais, termo);
    }

    public static void salvar(@Valid Material material) {
        if (material.nome == null || material.nome.trim().isEmpty()) {
            validation.addError("material.nome", "Nome é obrigatório");
        }
        if (material.categoria == null || material.categoria.trim().isEmpty()) {
            validation.addError("material.categoria", "Categoria é obrigatória");
        }
        if (material.codigo == null || material.codigo.trim().isEmpty()) {
            validation.addError("material.codigo", "Código é obrigatório");
        }
        if (material.quantidade < 0) {
            validation.addError("material.quantidade", "Quantidade inválida");
        }

        if (validation.hasErrors()) {
            flash.error("Preencha todos os campos corretamente.");
            render("Materiais/form.html", material);
            return;
        }

        if (material.id != null) {
            Material antigo = Material.findById(material.id);
            if (antigo != null) {
                antigo.nome = material.nome;
                antigo.categoria = material.categoria;
                antigo.codigo = material.codigo;
                antigo.quantidade = material.quantidade;
                antigo.descricao = material.descricao;
                antigo.status = material.quantidade == 0 ? Status.INATIVO : Status.ATIVO;
                antigo.save();
            }
        } else {
            material.status = material.quantidade == 0 ? Status.INATIVO : Status.ATIVO;
            material.save();
        }
        flash.success("Material salvo com sucesso!");
        listar(null);
    }

    public static void editar(Long id) {
        Material material = Material.findById(id);
        render("Materiais/form.html", material);
    }

    public static void remover(Long id) {
        Material material = Material.findById(id);
        if (material != null) {
            material.delete();
            flash.success("Material removido!");
        }
        listar(null);
    }
}
