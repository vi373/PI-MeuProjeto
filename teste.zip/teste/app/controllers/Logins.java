package controllers;

import play.mvc.*;
import models.Usuario;

public class Logins extends Controller {

    public static void form() {
        render();
    }

    public static void autenticar(String login, String senha) {
        if (login == null || senha == null || login.trim().isEmpty() || senha.trim().isEmpty()) {
            flash.error("Preencha todos os campos.");
            form();
        }

        Usuario u = Usuario.autenticar(login, senha);
        if (u == null) {
            flash.error("Login ou senha incorretos!");
            form();
        } else {
            session.put("usuarioLogado", u.login);
            session.put("usuarioNome", u.nome);
            session.put("usuarioPerfil", u.perfil.name());
            Application.bemVindo();
        }
    }

    public static void logout() {
        session.clear();
        flash.success("Você saiu do sistema.");
        Application.index();
    }
}
