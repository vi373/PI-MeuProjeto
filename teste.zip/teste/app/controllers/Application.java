package controllers;

import play.mvc.Controller;

public class Application extends Controller {

    // Tela inicial (apenas login e cadastro)
    public static void index() {
        render();
    }

    // Tela após login
    public static void bemVindo() {
        if (!session.contains("usuarioLogado")) {
            Logins.form();
        }
        render();
    }
}
