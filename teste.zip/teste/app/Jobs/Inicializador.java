package Jobs;

import play.jobs.*;
import play.*;
import models.*;

@OnApplicationStart
public class Inicializador extends Job {
    public void doJob() {
        try {
            if (Usuario.find("byLogin", "admin").first() == null) {
                Departamento dept = new Departamento("Administração", 0);
                dept.save();

                Usuario admin = new Usuario();
                admin.nome = "Administrador";
                admin.login = "admin";
                admin.email = "admin@local";
                admin.departamento = dept;
                admin.perfil = Perfil.ADMINISTRADOR;
                admin.setSenha("admin"); // senha padrão: admin
                admin.status = Status.ATIVO;
                admin.save();

                Logger.info("Usuário admin criado (login: admin / senha: admin). Troque a senha ao entrar.");
            } else {
                Logger.info("Admin já existe.");
            }
        } catch (Exception e) {
            Logger.error(e, "Erro ao inicializar dados");
        }
    }
}
